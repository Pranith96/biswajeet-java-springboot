
public class Example {

	public static void main(String[] args) {

		int i = 0;

		while (i < 10) {
			System.out.println(i);
			i++;
		}

		System.out.println("...........");
		int k = 10;

		do {
			System.out.println(k);
			k++;
		} while (k < 20);
	}
}
