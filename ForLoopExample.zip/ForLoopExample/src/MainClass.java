
public class MainClass {

	public static void main(String[] args) {
		Example ex = new Example();
		ex.displayNum(15);
		System.out.println(".................Even............");
		ex.displayEvenNum(15);

	}
}
