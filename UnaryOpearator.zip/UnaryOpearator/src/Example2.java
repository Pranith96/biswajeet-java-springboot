
public class Example2 {

	public void display_1() {
		int i = 10;
		int j = i++; // 10
		System.out.println(i); // 10+1 = 11
		System.out.println(j);
	}
}
