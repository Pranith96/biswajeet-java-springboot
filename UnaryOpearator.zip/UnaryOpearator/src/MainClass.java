
public class MainClass {

	public static void main(String[] args) {
		Example ex = new Example();
		ex.display();
		System.out.println(".................");
		ex.display1();
		System.out.println(".................");
		ex.display2();
		System.out.println(".................");
		ex.display3();
		
		Example3 ex2 = new Example3();
		ex2.display_3();
	}
}
