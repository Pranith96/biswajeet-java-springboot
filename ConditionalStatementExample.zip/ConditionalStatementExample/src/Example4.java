public class Example4 {

	public static void main(String[] args) {

		char ch = 'a';

		switch (ch) {
		case 'a':
			System.out.println("Vowels a");
			break;
		case 'e':
			System.out.println("Vowels e");
			break;
		case 'i':
			System.out.println("Vowels i");
			break;
		case 'o':
			System.out.println("Vowels o");
			break;
		case 'u':
			System.out.println("Vowels u");
			break;
		default:
			System.out.println("Consonents");
			break;
		}
	}
}
