
public class Example {

	public static void main(String[] args) {
		for (int i = 0; i < 3; i++) { // Rows
			System.out.println("i value: " + i);
			for (int j = 1; j < 4; j++) { // Columns
				System.out.println("j value:" + j);
			}
		}
	}
}
